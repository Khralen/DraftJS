# DraftJS AutoComplete Plugin Creator

[![npm](https://img.shields.io/npm/v/draft-js-autocomplete-plugin-creator.svg)](https://www.npmjs.com/package/draft-js-autocomplete-plugin-creator)

The goal of this plugin creator to is to make developing custom autocompletion plugins for 
[draft-js-plugins](https://github.com/draft-js-plugins/draft-js-plugins) easier and consolidate common
logic internal to the completion logic. Much of the original logic comes from the [Mention Plugin](https://github.com/draft-js-plugins/draft-js-plugins/tree/master/draft-js-mention-plugin).

### API

API documentation is in progress, for now please see the examples.
