import PostEditor from "./postEditor";

export default PostEditor;
